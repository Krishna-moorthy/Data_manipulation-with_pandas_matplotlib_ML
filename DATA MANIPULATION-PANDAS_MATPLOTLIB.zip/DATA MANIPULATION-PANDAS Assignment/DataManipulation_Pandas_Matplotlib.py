# -*- coding: utf-8 -*-
"""
Created on Fri Jul 13 12:47:23 2018

@author: Krishnamoorthy KBhat
"""
import matplotlib.pyplot as plt
data=pd.read_excel('titanic3.xls')
#1)use pandas to read the file,use group by method to calculate the proportion of passengers that survived by gender
pd.crosstab(data['survived'],data['sex'])
data['sex'].value_counts()# it can be done using value_counts also but i donot know
pd.crosstab(data['survived'],data['pclass'])
#2)use pandas to read the file,use group by method to calculate the proportion of passengers that survived by pclass,gender
ages=data['age']
bins=[14,20,21,60,100]#bins and group should be equal
group=['young','adultants','adult','senior']#bins and group should be equal
cats1=pd.cut(ages,bins,labels=group)
#calculate survived using age,pclass and gender
data['survived'].value_counts()#gives who died and survived
data[data['survived']>0]['age']
data[data['survived']>0]['pclass']
data[data['survived']>0]['sex']
#3)create age category like children under 14,adolscents 15-20 ,adults 21-64,seniors 65 onwards & calculate the survival proportion using this proportional,pclass & gender,also cal. non-survival proportions
a=data[data['survived']==0]['age']
a.value_counts()
data[data['survived']==0]['pclass']
data[data['survived']==0]['sex']



data.hist()#used for plotting histogram 
 #multivariant data analysis
 from pandas.tools.plotting import scatter_matrix
 scatter_matrix(data)
 
 